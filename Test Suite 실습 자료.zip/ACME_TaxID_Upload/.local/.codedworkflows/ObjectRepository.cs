using UiPath.CodedWorkflows.DescriptorIntegration;

namespace ACME_TaxID_Upload.ObjectRepository
{
    public static class Descriptors
    {
        public static class __New_application
        {
            static string _reference = "6Gz5hXQOQkO8lkPxyX0DFQ/9VjRdNwWTEmtk-bXZmozkA";
            public static _Implementation.___New_application.__Chrome_ACME_System_1___Order_Upload Chrome_ACME_System_1___Order_Upload { get; private set; } = new _Implementation.___New_application.__Chrome_ACME_System_1___Order_Upload();
            public static _Implementation.___New_application.__New_application New_application { get; private set; } = new _Implementation.___New_application.__New_application();
        }
    }
}

namespace ACME_TaxID_Upload._Implementation
{
    internal class ScreenDescriptorDefinition : IScreenDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }
    }

    internal class ElementDescriptorDefinition : IElementDescriptorDefinition
    {
        public IScreenDescriptor Screen { get; set; }

        public string Reference { get; set; }

        public string DisplayName { get; set; }

        public IElementDescriptor ParentElement { get; set; }

        public IElementDescriptor Element { get; set; }
    }

    namespace ___New_application._Chrome_ACME_System_1___Order_Upload
    {
        public class __ACME_System_1 : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __ACME_System_1(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "6Gz5hXQOQkO8lkPxyX0DFQ/j33grDPWtUSObNQmv-HeeQ", DisplayName = "ACME System 1", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace ___New_application._Chrome_ACME_System_1___Order_Upload
    {
        public class __Log_Out : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Log_Out(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "6Gz5hXQOQkO8lkPxyX0DFQ/ewVCECNYwEqrj1QSleIq-A", DisplayName = "Log Out", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace ___New_application
    {
        public class __Chrome_ACME_System_1___Order_Upload : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __Chrome_ACME_System_1___Order_Upload()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "6Gz5hXQOQkO8lkPxyX0DFQ/z9DPJlabZ0O5ilVs_qlF4A", DisplayName = "Chrome ACME System 1 - Order Upload", Screen = this};
                ACME_System_1 = new _Implementation.___New_application._Chrome_ACME_System_1___Order_Upload.__ACME_System_1(this, null);
                Log_Out = new _Implementation.___New_application._Chrome_ACME_System_1___Order_Upload.__Log_Out(this, null);
            }

            public _Implementation.___New_application._Chrome_ACME_System_1___Order_Upload.__ACME_System_1 ACME_System_1 { get; private set; }

            public _Implementation.___New_application._Chrome_ACME_System_1___Order_Upload.__Log_Out Log_Out { get; private set; }
        }
    }

    namespace ___New_application._New_application
    {
        public class __Log_Out : IElementDescriptor
        {
            private readonly IScreenDescriptor _screenDescriptor;
            private readonly IElementDescriptor _parentElementDescriptor;
            private readonly IElementDescriptorDefinition _elementDescriptor;
            public IElementDescriptorDefinition GetDefinition()
            {
                return _elementDescriptor;
            }

            public __Log_Out(IScreenDescriptor screenDescriptor, IElementDescriptor parentElementDescriptor)
            {
                _screenDescriptor = screenDescriptor;
                _parentElementDescriptor = parentElementDescriptor;
                _elementDescriptor = new ElementDescriptorDefinition{Reference = "6Gz5hXQOQkO8lkPxyX0DFQ/dgw2iw7xuUelBt4Pi8q1eg", DisplayName = "Log Out", Element = this, ParentElement = _parentElementDescriptor, Screen = screenDescriptor};
            }
        }
    }

    namespace ___New_application
    {
        public class __New_application : IScreenDescriptor
        {
            public IScreenDescriptorDefinition GetDefinition()
            {
                return _screenDescriptor;
            }

            private readonly ScreenDescriptorDefinition _screenDescriptor;
            public __New_application()
            {
                _screenDescriptor = new ScreenDescriptorDefinition{Reference = "6Gz5hXQOQkO8lkPxyX0DFQ/oedWdYbmP02qKSP0AcpNrQ", DisplayName = "New application", Screen = this};
                Log_Out = new _Implementation.___New_application._New_application.__Log_Out(this, null);
            }

            public _Implementation.___New_application._New_application.__Log_Out Log_Out { get; private set; }
        }
    }
}