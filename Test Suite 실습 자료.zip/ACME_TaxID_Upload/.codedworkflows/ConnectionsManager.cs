using UiPath.CodedWorkflows;
using System;

namespace ACME_TaxID_Upload
{
    public class ConnectionsManager
    {
        public ConnectionsManager(ICodedWorkflowsServiceContainer resolver)
        {
        }
    }
}