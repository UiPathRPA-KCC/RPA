using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UiPath.CodedWorkflows;
using UiPath.CodedWorkflows.Interfaces;
using UiPath.Activities.Contracts;
using ACME_TaxID_Upload;
using ACME_TaxID_Upload.ObjectRepository;
using System.Data;
using UiPath.Core;
using UiPath.Core.Activities.Storage;
using UiPath.Excel;
using UiPath.Excel.Activities;
using UiPath.Excel.Activities.API;
using UiPath.Excel.Activities.API.Models;
using UiPath.Mail.Activities.Api;
using UiPath.Orchestrator.Client.Models;
using UiPath.Testing;
using UiPath.Testing.Activities.TestData;
using UiPath.Testing.Activities.TestDataQueues.Enums;
using UiPath.Testing.Enums;
using UiPath.UIAutomationNext.API.Contracts;
using UiPath.UIAutomationNext.API.Models;
using UiPath.UIAutomationNext.Enums;

[assembly: WorkflowRunnerServiceAttribute(typeof(ACME_TaxID_Upload.WorkflowRunnerService))]
namespace ACME_TaxID_Upload
{
    public class WorkflowRunnerService
    {
        private readonly ICodedWorkflowServices _services;
        public WorkflowRunnerService(ICodedWorkflowServices services)
        {
            _services = services;
        }

        /// <summary>
        /// Invokes the Process/Upload_OrderList.xaml
        /// </summary>
        public bool Upload_OrderList(string in_UploadOrderURL, string in_TaxID)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\Upload_OrderList.xaml", new Dictionary<string, object>{{"in_UploadOrderURL", in_UploadOrderURL}, {"in_TaxID", in_TaxID}}, default, default, default, GetAssemblyName());
            return (bool)result["out_CheckUI"];
        }

        /// <summary>
        /// Invokes the Process/ACME_Login.xaml
        /// </summary>
        public bool ACME_Login(string in_ID, string in_Password)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\ACME_Login.xaml", new Dictionary<string, object>{{"in_ID", in_ID}, {"in_Password", in_Password}}, default, default, default, GetAssemblyName());
            return (bool)result["out_IsLogout"];
        }

        /// <summary>
        /// Invokes the Process/Save_as_TaxID.xlsx.xaml
        /// </summary>
        public int Save_as_TaxID_xlsx(string in_OrderListFilePath)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\Save_as_TaxID.xlsx.xaml", new Dictionary<string, object>{{"in_OrderListFilePath", in_OrderListFilePath}}, default, default, default, GetAssemblyName());
            return (int)result["out_FileCnt"];
        }

        /// <summary>
        /// Invokes the Main.xaml
        /// </summary>
        public void Main()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Main.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Process/MoveFile.xaml
        /// </summary>
        public bool MoveFile(string in_CopyFIlePath, string in_PasteFilePath)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\MoveFile.xaml", new Dictionary<string, object>{{"in_CopyFIlePath", in_CopyFIlePath}, {"in_PasteFilePath", in_PasteFilePath}}, default, default, default, GetAssemblyName());
            return (bool)result["out_FileCheck"];
        }

        /// <summary>
        /// Invokes the Process/Test/TC004_문서 업로드 테스트.xaml
        /// </summary>
        public void TC004_문서_업로드_테스트(string UploadOrderURL, string TaxID)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\Test\TC004_문서 업로드 테스트.xaml", new Dictionary<string, object>{{"UploadOrderURL", UploadOrderURL}, {"TaxID", TaxID}}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Process/Test/TC002_Excel 데이터 처리 테스트.xaml
        /// </summary>
        public void TC002_Excel_데이터_처리_테스트(string OrderListFilePath)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\Test\TC002_Excel 데이터 처리 테스트.xaml", new Dictionary<string, object>{{"OrderListFilePath", OrderListFilePath}}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Process/Test/TC003_ACME 로그인 테스트.xaml
        /// </summary>
        public void TC003_ACME_로그인_테스트(System.Collections.Generic.IDictionary<string, object> aCMELoginAccounts)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\Test\TC003_ACME 로그인 테스트.xaml", new Dictionary<string, object>{{"aCMELoginAccounts", aCMELoginAccounts}}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Process/Test/TC001_파일 복사 테스트.xaml
        /// </summary>
        public void TC001_파일_복사_테스트(string PasteFilePath, string CopyFilePath, string ExpectedResult)
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\Test\TC001_파일 복사 테스트.xaml", new Dictionary<string, object>{{"PasteFilePath", PasteFilePath}, {"CopyFilePath", CopyFilePath}, {"ExpectedResult", ExpectedResult}}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the Process/AddLoginTestDataQueue/AddLoginTestDataQueue.xaml
        /// </summary>
        public void AddLoginTestDataQueue()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"Process\AddLoginTestDataQueue\AddLoginTestDataQueue.xaml", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        /// <summary>
        /// Invokes the TC001_ 파일 복사 테스트.cs
        /// </summary>
        public void TC001__파일_복사_테스트()
        {
            var result = _services.WorkflowInvocationService.RunWorkflow(@"TC001_ 파일 복사 테스트.cs", new Dictionary<string, object>{}, default, default, default, GetAssemblyName());
        }

        private string GetAssemblyName()
        {
            var assemblyProvider = _services.Container.Resolve<ILibraryAssemblyProvider>();
            return assemblyProvider.GetLibraryAssemblyName(GetType().Assembly);
        }
    }
}